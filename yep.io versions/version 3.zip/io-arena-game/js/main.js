import { GameEngine } from './gameEngine.js';
import { Player } from './entities.js';
import { ITEMS_DB, RARITY_COLORS } from './items.js';

let selectedClass = 'triangle';

window.globalAccountXP = 0;
window.globalAccountLevel = 1;

window.gameSettings = { 
    highQuality: true, particles: true, showNames: true, showFps: false,
    keybinds: { up: 'w', down: 's', left: 'a', right: 'd', dash: ' ' }
};

window.hourlyStats = { kills: 0, time: 0, points: 0, distance: 0 };
let currentShopHour = new Date().getHours();
window.claimedItems = {}; 

window.equippedItems = { Skin: null, Trail: null, Banner: null, Color: null };

window.lifetimeStats = { matches: 0, kills: 0, time: 0, points: 0, distance: 0 };
window.matchHistory = [];

function getRarityScore(type, req) {
    if (type === 'kills') { if (req < 15) return 1; if (req < 30) return 2; if (req < 50) return 3; if (req < 80) return 4; return 5; }
    if (type === 'distance') { if (req < 15000) return 1; if (req < 30000) return 2; if (req < 60000) return 3; if (req < 100000) return 4; return 5; }
    if (type === 'time') { if (req < 300) return 1; if (req < 600) return 2; if (req < 1200) return 3; if (req < 2400) return 4; return 5; }
    if (type === 'points') { if (req < 500) return 1; if (req < 1500) return 2; if (req < 3000) return 3; if (req < 6000) return 4; return 5; }
    return 1;
}

function formatTime(secs) {
    if (!secs || isNaN(secs)) return '0m 0s';
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}m ${s}s`;
}

const canvas = document.getElementById('gameCanvas');
const game = new GameEngine(canvas);

game.startDemo();

const lockerPreviewCanvas = document.getElementById('lockerPreviewCanvas');
const lockerPreviewCtx = lockerPreviewCanvas.getContext('2d');

const dpr = window.devicePixelRatio || 1;
if (lockerPreviewCanvas) {
    lockerPreviewCanvas.width = 300 * dpr; 
    lockerPreviewCanvas.height = 300 * dpr; 
    lockerPreviewCtx.scale(dpr, dpr);
}

let previewAngle = 0;
function renderPreview() {
    previewAngle += 0.015;
    
    if (lockerPreviewCtx) {
        lockerPreviewCtx.clearRect(0, 0, lockerPreviewCanvas.width, lockerPreviewCanvas.height);
        
        const dummy = new Player(150, 150, selectedClass, ""); 
        dummy.equipped = window.equippedItems;
        
        if (dummy.equipped.Color && ITEMS_DB[dummy.equipped.Color]) {
            const dbColor = ITEMS_DB[dummy.equipped.Color].value;
            if (dbColor === 'gold') dummy.color = '#ffe600'; 
        } else {
            dummy.color = '#d3d3d3'; 
        }

        dummy.angle = previewAngle;
        dummy.size = 60; 
        
        let tempShowNames = window.gameSettings.showNames;
        window.gameSettings.showNames = false;
        dummy.draw(lockerPreviewCtx);
        window.gameSettings.showNames = tempShowNames;
    }
    
    requestAnimationFrame(renderPreview);
}
renderPreview();

document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
        e.target.classList.add('active');
        
        const targetTab = e.target.dataset.target;
        document.getElementById(targetTab).classList.add('active');
        
        const seasonLevelUI = document.querySelector('.player-level-ui');
        if (targetTab === 'locker') {
            seasonLevelUI.classList.add('hidden');
        } else {
            seasonLevelUI.classList.remove('hidden');
        }
        
        if (targetTab === 'season') renderSeasonStore();
        if (targetTab === 'store') renderMainStore();
        if (targetTab === 'locker') renderLocker();
        if (targetTab === 'stats') renderStats(); 
    });
});

document.querySelectorAll('.class-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
        document.querySelectorAll('.class-btn').forEach(b => b.classList.remove('active'));
        e.target.classList.add('active');
        selectedClass = e.target.dataset.class;
    });
});

document.getElementById('settings-btn').addEventListener('click', () => { document.getElementById('settings-modal').classList.remove('hidden'); });

document.getElementById('close-settings-btn').addEventListener('click', () => {
    window.gameSettings.highQuality = document.getElementById('set-hq').checked;
    window.gameSettings.particles = document.getElementById('set-particles').checked;
    window.gameSettings.showNames = document.getElementById('set-names').checked;
    window.gameSettings.showFps = document.getElementById('set-fps').checked;
    
    const fpsDisplay = document.getElementById('fps-display');
    if (window.gameSettings.showFps) fpsDisplay.classList.remove('hidden');
    else fpsDisplay.classList.add('hidden');

    document.getElementById('settings-modal').classList.add('hidden');
});

let listeningAction = null;
const formatKeyName = (key) => key === ' ' ? 'SPACE' : key.toUpperCase();

document.querySelectorAll('.keybind-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
        document.querySelectorAll('.keybind-btn').forEach(b => b.classList.remove('listening'));
        listeningAction = e.target.dataset.action;
        e.target.classList.add('listening');
        e.target.innerText = "PRESS KEY";
    });
});

document.addEventListener('keydown', (e) => {
    if (listeningAction) {
        e.preventDefault(); 
        const key = e.key.toLowerCase();
        window.gameSettings.keybinds[listeningAction] = key;
        const btn = document.querySelector(`.keybind-btn[data-action="${listeningAction}"]`);
        btn.innerText = formatKeyName(key);
        btn.classList.remove('listening');
        listeningAction = null;
    }
});

function updateMenuXPBar() {
    const xpRequired = window.globalAccountLevel * 1000;
    const progressPercent = Math.min(100, (window.globalAccountXP / xpRequired) * 100);
    document.getElementById('menu-xp-bar').style.width = `${progressPercent}%`;
    document.getElementById('menu-level').innerText = window.globalAccountLevel;
}

document.getElementById('play-btn').addEventListener('click', () => {
    document.getElementById('main-menu').classList.add('hidden');
    document.getElementById('game-ui').classList.remove('hidden');
    document.querySelector('.hud').classList.remove('hidden');
    game.start(selectedClass);
});

document.getElementById('return-lobby-btn').addEventListener('click', () => {
    document.getElementById('game-over-screen').classList.add('hidden');
    document.getElementById('game-ui').classList.add('hidden');
    document.getElementById('main-menu').classList.remove('hidden');

    if (window.lastMatchStats) {
        window.hourlyStats.kills += window.lastMatchStats.kills || 0;
        window.hourlyStats.time += window.lastMatchStats.time || 0;
        window.hourlyStats.points += window.lastMatchStats.points || 0;
        window.hourlyStats.distance += window.lastMatchStats.distance || 0;
        
        window.lifetimeStats.matches += 1;
        window.lifetimeStats.kills += window.lastMatchStats.kills || 0;
        window.lifetimeStats.time += window.lastMatchStats.time || 0;
        window.lifetimeStats.points += window.lastMatchStats.points || 0;
        window.lifetimeStats.distance += window.lastMatchStats.distance || 0;
        
        window.matchHistory.unshift(window.lastMatchStats);
        if (window.matchHistory.length > 20) {
            window.matchHistory.pop();
        }

        window.lastMatchStats = null; 
    }

    updateMenuXPBar(); 
    game.startDemo();
});

let currentLockerCategory = null;

window.openLockerCategory = (cat) => {
    currentLockerCategory = cat;
    renderLocker();
};

document.body.addEventListener('click', (e) => {
    if (e.target.id === 'locker-back-btn') {
        currentLockerCategory = null;
        renderLocker();
    }
});

window.toggleEquip = (itemId, catOverride = null) => {
    if (itemId === null && catOverride) {
        window.equippedItems[catOverride] = null;
    } else {
        const item = ITEMS_DB[itemId];
        if (!item) return;
        
        if (window.equippedItems[item.category] === itemId) {
            window.equippedItems[item.category] = null;
        } else {
            window.equippedItems[item.category] = itemId;
        }
    }
    
    if (document.getElementById('locker').classList.contains('active')) renderLocker();
    if (document.getElementById('season').classList.contains('active')) renderSeasonStore();
    if (document.getElementById('store').classList.contains('active')) renderMainStore();
};

function renderLocker() {
    const slotsView = document.getElementById('locker-slots-view');
    const itemsView = document.getElementById('locker-items-view');

    if (currentLockerCategory === null) {
        slotsView.classList.remove('hidden');
        itemsView.classList.add('hidden');
        
        slotsView.innerHTML = '';
        const categories = ['Skin', 'Trail', 'Banner', 'Color'];
        
        categories.forEach(cat => {
            const equippedId = window.equippedItems[cat];
            const item = equippedId ? ITEMS_DB[equippedId] : null;
            
            const icon = item ? item.icon : '✖';
            const name = item ? item.name : 'Default';
            const color = item ? (item.color || RARITY_COLORS[getRarityScore(item.type, item.req)]) : '#888';
            
            slotsView.innerHTML += `
                <div class="locker-slot" onclick="openLockerCategory('${cat}')" style="--slot-color: ${color};">
                    <div class="slot-header">${cat}</div>
                    <div class="slot-icon">${icon}</div>
                    <div class="slot-name">${name}</div>
                </div>
            `;
        });
    } else {
        slotsView.classList.add('hidden');
        itemsView.classList.remove('hidden');
        
        document.getElementById('locker-category-title').innerText = `CHOOSE ${currentLockerCategory}`;
        
        const grid = document.getElementById('locker-item-grid');
        grid.innerHTML = '';
        
        const isDefaultEquipped = !window.equippedItems[currentLockerCategory];
        grid.innerHTML += `
            <div class="store-item unlocked" style="--rarity-color: #888;">
                <div class="item-icon">✖</div>
                <div style="font-size: 0.8rem; color: #888; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; margin-bottom: -5px;">DEFAULT</div>
                <div class="item-name">None</div>
                <button class="btn-equip ${isDefaultEquipped ? 'equipped' : ''}" onclick="window.toggleEquip(null, '${currentLockerCategory}')">
                    ${isDefaultEquipped ? '✓ EQUIPPED' : 'EQUIP'}
                </button>
            </div>
        `;

        const claimedKeys = Object.keys(window.claimedItems);
        claimedKeys.forEach(id => {
            const item = ITEMS_DB[id];
            if (!item || item.category !== currentLockerCategory) return;
            
            let color = item.color || RARITY_COLORS[getRarityScore(item.type, item.req)];
            const isEquipped = window.equippedItems[item.category] === item.id;
            
            grid.innerHTML += `
                <div class="store-item unlocked" style="--rarity-color: ${color};">
                    <div class="item-icon">${item.icon}</div>
                    <div style="font-size: 0.8rem; color: ${color}; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; margin-bottom: -5px;">${item.category}</div>
                    <div class="item-name">${item.name}</div>
                    <button class="btn-equip ${isEquipped ? 'equipped' : ''}" onclick="window.toggleEquip('${item.id}')">
                        ${isEquipped ? '✓ EQUIPPED' : 'EQUIP'}
                    </button>
                </div>
            `;
        });
    }
}

function renderStats() {
    document.getElementById('stat-account-level').innerText = window.globalAccountLevel;
    document.getElementById('stat-matches').innerText = window.lifetimeStats.matches;
    document.getElementById('stat-kills').innerText = window.lifetimeStats.kills;
    document.getElementById('stat-points').innerText = Math.floor(window.lifetimeStats.points);
    document.getElementById('stat-time').innerText = formatTime(window.lifetimeStats.time);
    
    const historyList = document.getElementById('match-history-list');
    
    if (window.matchHistory.length === 0) {
        historyList.innerHTML = '<p style="color: #aaa; text-align: center; padding: 20px; grid-column: span 5;">Play a match to see your history!</p>';
        return;
    }
    
    historyList.innerHTML = '';
    
    window.matchHistory.forEach(match => {
        let rankColor = '#a0a0a0'; 
        let rank = match.rank ? match.rank : '?';
        let tot = match.totalPlayers ? match.totalPlayers : '?';
        
        if (rank === 1) rankColor = '#ffe600'; 
        else if (rank !== '?' && rank <= 5) rankColor = '#00ffcc'; 
        
        let pClass = match.playerClass ? match.playerClass.charAt(0).toUpperCase() + match.playerClass.slice(1) : 'Unknown';

        const html = `
            <div class="match-card" style="border-left-color: ${rankColor};">
                <div class="match-detail-item">
                    <span class="match-detail-label">RANK</span>
                    <div class="match-rank" style="color: ${rankColor};">
                        #${rank}<span style="font-size: 0.8rem; color: #666;">/${tot}</span>
                    </div>
                </div>
                <div class="match-detail-item">
                    <span class="match-detail-label">CLASS</span>
                    <span class="match-detail-val" style="color: #bbb;">${pClass}</span>
                </div>
                <div class="match-detail-item">
                    <span class="match-detail-label">KILLS</span>
                    <span class="match-detail-val">${match.kills || 0}</span>
                </div>
                <div class="match-detail-item">
                    <span class="match-detail-label">POINTS</span>
                    <span class="match-detail-val">${Math.floor(match.points || 0)}</span>
                </div>
                <div class="match-detail-item">
                    <span class="match-detail-label">TIME ALIVE</span>
                    <span class="match-detail-val">${formatTime(match.time || 0)}</span>
                </div>
            </div>
        `;
        historyList.innerHTML += html;
    });
}

function renderSeasonStore() {
    const grid = document.getElementById('season-grid');
    grid.innerHTML = '';
    
    const progressPercent = Math.min(100, (window.globalAccountLevel / 50) * 100);
    document.getElementById('season-progress-bar').style.width = `${progressPercent}%`;

    const sItems = ['s_banner', 's_trail', 's_skin1', 's_skin2'];

    sItems.forEach(id => {
        const item = ITEMS_DB[id];
        if (!item) return;
        const isUnlocked = window.globalAccountLevel >= item.req;
        const isClaimed = window.claimedItems[item.id];
        const isEquipped = window.equippedItems[item.category] === item.id;
        
        let buttonHtml = '';
        if (isUnlocked && !isClaimed) {
            buttonHtml = `<button class="btn-claim" data-id="${item.id}"><div class="fill"></div><span>HOLD TO CLAIM</span></button>`;
        } else if (isClaimed) {
            buttonHtml = `<button class="btn-equip ${isEquipped ? 'equipped' : ''}" onclick="window.toggleEquip('${item.id}')">${isEquipped ? '✓ EQUIPPED' : 'EQUIP'}</button>`;
        }

        const html = `
            <div class="store-item ${isUnlocked ? 'unlocked' : 'locked'}" style="--rarity-color: ${item.color};">
                <div class="item-icon">${item.icon}</div>
                <div style="font-size: 0.8rem; color: ${item.color}; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; margin-bottom: -5px; text-shadow: 0 0 5px ${item.color}40;">${item.category}</div>
                <div class="item-name">${item.name}</div>
                <div class="item-req" style="color: ${item.color};">${isClaimed ? '✓ CLAIMED' : isUnlocked ? 'UNLOCKED!' : `Requires Level ${item.req}`}</div>
                ${buttonHtml}
            </div>
        `;
        grid.innerHTML += html;
    });
}

function renderMainStore() {
    const grid = document.getElementById('main-store-grid');
    grid.innerHTML = '';
    
    let shopItems = [
        ITEMS_DB['m_skin'],
        ITEMS_DB['m_banner'],
        ITEMS_DB['m_trail'],
        ITEMS_DB['m_color']
    ].filter(item => item !== undefined);

    shopItems.sort((a, b) => getRarityScore(a.type, a.req) - getRarityScore(b.type, b.req));

    shopItems.forEach(item => {
        const currentValue = window.hourlyStats[item.type];
        const isUnlocked = currentValue >= item.req;
        const isClaimed = window.claimedItems[item.id];
        const isEquipped = window.equippedItems[item.category] === item.id;
        const progressPercent = Math.min(100, (currentValue / item.req) * 100);
        
        const rarityScore = getRarityScore(item.type, item.req);
        const color = RARITY_COLORS[rarityScore];
        
        let buttonHtml = '';
        if (isUnlocked && !isClaimed) {
            buttonHtml = `<button class="btn-claim" data-id="${item.id}"><div class="fill"></div><span>HOLD TO CLAIM</span></button>`;
        } else if (isClaimed) {
            buttonHtml = `<button class="btn-equip ${isEquipped ? 'equipped' : ''}" onclick="window.toggleEquip('${item.id}')">${isEquipped ? '✓ EQUIPPED' : 'EQUIP'}</button>`;
        } else {
            buttonHtml = `<div class="item-progress-bg"><div class="item-progress-fill" style="width: ${progressPercent}%; background: ${color}; box-shadow: 0 0 10px ${color};"></div></div>`;
        }
        
        const html = `
            <div class="store-item ${isUnlocked ? 'unlocked' : 'locked'}" style="--rarity-color: ${color};">
                <div class="item-icon">${item.icon}</div>
                <div style="font-size: 0.8rem; color: ${color}; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; margin-bottom: -5px; text-shadow: 0 0 5px ${color}40;">${item.category}</div>
                <div class="item-name">${item.name}</div>
                <div class="item-req" style="color: ${color};">${isClaimed ? '✓ CLAIMED' : isUnlocked ? 'UNLOCKED!' : `${Math.floor(currentValue)} / ${item.req} ${item.label}`}</div>
                ${buttonHtml}
            </div>
        `;
        grid.innerHTML += html;
    });
}

const startClaim = (e) => {
    const btn = e.target.closest('.btn-claim');
    if (!btn) return;
    
    const itemId = btn.dataset.id;
    const storeItem = btn.closest('.store-item');
    
    btn.classList.add('holding');
    storeItem.classList.add('shaking');

    btn.claimTimeout = setTimeout(() => {
        window.claimedItems[itemId] = true;
        btn.classList.remove('holding');
        storeItem.classList.remove('shaking');
        storeItem.classList.add('claimed-pop');
        
        setTimeout(() => {
            renderSeasonStore();
            renderMainStore();
            renderLocker();
        }, 500); 
    }, 1000); 
};

const stopClaim = (e) => {
    document.querySelectorAll('.btn-claim.holding').forEach(btn => {
        clearTimeout(btn.claimTimeout);
        btn.classList.remove('holding');
        btn.closest('.store-item').classList.remove('shaking');
    });
};

document.body.addEventListener('mousedown', startClaim);
document.body.addEventListener('touchstart', startClaim, {passive: true});
document.body.addEventListener('mouseup', stopClaim);
document.body.addEventListener('mouseleave', stopClaim);
document.body.addEventListener('touchend', stopClaim);

setInterval(() => {
    const now = new Date();
    const minutes = 59 - now.getMinutes();
    const seconds = 59 - now.getSeconds();
    document.getElementById('shop-timer').innerText = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

    if (now.getHours() !== currentShopHour) {
        currentShopHour = now.getHours();
        window.hourlyStats = { kills: 0, time: 0, points: 0, distance: 0 };
        if (document.getElementById('store').classList.contains('active')) renderMainStore();
    }
}, 1000);

// Initialize UI
renderSeasonStore();
renderMainStore();
updateMenuXPBar(); 

const devConsole = document.getElementById('dev-console');
const devInput = document.getElementById('dev-input');
const devLog = document.getElementById('dev-log');

function logDev(msg) {
    devLog.innerHTML += `<div>> ${msg}</div>`;
    devLog.scrollTop = devLog.scrollHeight;
}

window.addEventListener('keydown', (e) => {
    if (e.key === '`') {
        e.preventDefault();
        devConsole.classList.toggle('hidden');
        if (!devConsole.classList.contains('hidden')) devInput.focus();
    }
});

devInput.addEventListener('keydown', (e) => {
    if (e.key === '`') { e.preventDefault(); return; }
    if (e.key === 'Enter') {
        const val = devInput.value.trim();
        if (!val) return;
        
        logDev(val);
        devInput.value = '';
        
        const parts = val.split(' ');
        const cmd = parts[0].toLowerCase();
        const arg = parseInt(parts[1]);

        if (cmd === '/level' && !isNaN(arg)) {
            window.globalAccountLevel = arg;
            window.globalAccountXP = 0; 
            updateMenuXPBar();
            renderSeasonStore();
            if (document.getElementById('stats').classList.contains('active')) renderStats();
            logDev(`[SUCCESS] Account Level set to ${arg}.`);
        }
        else if (cmd === '/kills' && !isNaN(arg)) {
            window.hourlyStats.kills = arg; renderMainStore(); logDev(`[SUCCESS] Hourly kills set to ${arg}.`);
        }
        else if (cmd === '/dist' && !isNaN(arg)) {
            window.hourlyStats.distance = arg; renderMainStore(); logDev(`[SUCCESS] Hourly distance set to ${arg}.`);
        }
        else if (cmd === '/time' && !isNaN(arg)) {
            window.hourlyStats.time = arg; renderMainStore(); logDev(`[SUCCESS] Hourly time set to ${arg}.`);
        }
        else if (cmd === '/points' && !isNaN(arg)) {
            window.hourlyStats.points = arg; renderMainStore(); logDev(`[SUCCESS] Hourly points set to ${arg}.`);
        }
        else if (cmd === '/claimall') { 
            Object.keys(ITEMS_DB).forEach(k => window.claimedItems[k] = true);
            renderLocker();
            renderSeasonStore();
            renderMainStore();
            logDev(`[SUCCESS] Claimed all items.`);
        }
        else if (cmd === '/help') {
            logDev('Commands: /level [num], /kills [num], /dist [num], /time [num], /points [num], /claimall');
        }
        else {
            logDev('<span style="color: red;">[ERROR] Unknown command.</span>');
        }
    }
});