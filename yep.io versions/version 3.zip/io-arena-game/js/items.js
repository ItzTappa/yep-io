// ==========================================
// YEP.IO - ITEM & COSMETIC DATABASE
// ==========================================

export const RARITY_COLORS = { 
    1: '#a0a0a0', // Common (Gray)
    2: '#22c55e', // Uncommon (Green)
    3: '#3b82f6', // Rare (Blue)
    4: '#a855f7', // Epic (Purple)
    5: '#f97316'  // Legendary (Orange)
};

export const ITEMS_DB = {
    // ==========================================
    // SEASON STORE ITEMS (Unlocked by Account Level)
    // ==========================================
    // req: Account Level needed to unlock
    
    's_banner': { id: 's_banner', name: 'Veteran', category: 'Banner', icon: '🏴', color: RARITY_COLORS[2], req: 10, value: '🏴' },
    's_trail':  { id: 's_trail',  name: 'Plasma',  category: 'Trail',  icon: '☄️', color: RARITY_COLORS[3], req: 25, value: '#00ffff' },
    's_skin1':  { id: 's_skin1',  name: 'Neon Striker', category: 'Skin', icon: '✨', color: RARITY_COLORS[4], req: 35, value: 'neon' },
    's_skin2':  { id: 's_skin2',  name: 'Dark Matter',  category: 'Skin', icon: '🌌', color: RARITY_COLORS[5], req: 50, value: 'dark' },
    
    // ==========================================
    // HOURLY STORE ITEMS (Unlocked by Match Stats)
    // ==========================================
    // type: The stat required ('kills', 'distance', 'time', 'points')
    // req: The amount of that stat needed before the hour resets
    // label: What shows up in the UI (e.g., 'Kills', 'Pts')
    
    'm_skin':   { id: 'm_skin',   name: 'Gladiator', category: 'Skin',   icon: '⚔️', type: 'kills',    req: 40,     label: 'Kills', value: 'gladiator' },
    'm_banner': { id: 'm_banner', name: 'Marathon',  category: 'Banner', icon: '🏃', type: 'distance', req: 120000, label: 'Dist.', value: '🏃' },
    'm_trail':  { id: 'm_trail',  name: 'Survivor',  category: 'Trail',  icon: '⏱️', type: 'time',     req: 400,    label: 'Secs',  value: '#22c55e' },
    'm_color':  { id: 'm_color',  name: 'High Roller',category: 'Color', icon: '💎', type: 'points',   req: 5000,   label: 'Pts',   value: 'gold' }

    // TO ADD A NEW ITEM:
    // 1. Copy an existing line above.
    // 2. Change the 'id' (make sure it is unique).
    // 3. Set the 'category' to exactly: 'Skin', 'Trail', 'Banner', or 'Color'.
    // 4. If it's a Skin, 'value' must match a skin coded in entities.js (e.g. 'neon', 'dark').
    // 5. If it's a Trail or Color, 'value' should be a hex code (e.g. '#ff0000').
    // 6. If it's a Banner, 'value' should be the emoji (e.g. '👑').
};