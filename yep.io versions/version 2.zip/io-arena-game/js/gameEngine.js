import { Player, Bot, Orb, Projectile, Particle, getWeightedUpgrades } from './entities.js';
import { distance } from './utils.js';

export class GameEngine {
    constructor(canvas) {
        this.canvas = canvas; this.ctx = canvas.getContext('2d');
        this.width = window.innerWidth; this.height = window.innerHeight;
        const dpr = window.devicePixelRatio || 1;
        this.canvas.width = this.width * dpr; this.canvas.height = this.height * dpr;
        this.canvas.style.width = `${this.width}px`; this.canvas.style.height = `${this.height}px`;
        this.ctx.scale(dpr, dpr);

        this.worldSize = 4000;
        this.player = null; this.bots = []; this.orbs = []; this.projectiles = []; this.particles = [];
        this.mouseX = this.width / 2; this.mouseY = this.height / 2;
        this.keys = {}; this.frameCount = 0; 
        
        this.levelUpTimeout = null; 
        this.accountLevelUpTimeout = null; 
        this.animationId = null; 
        
        this.fpsInterval = 1000 / 60; 
        this.lastTime = 0;
        this.lastFpsTime = performance.now(); 
        this.framesThisSecond = 0;

        this.isGameOver = false;
        this.matchStartTime = 0;
        this.matchXPEarned = 0; 
        
        this.distanceTraveled = 0;
        this.lastPlayerPos = { x: 0, y: 0 };

        this.pendingUpgrades = 0; 
        this.currentUpgradeChoices = [];
        this.isChoosingUpgrade = false;
        this.pointsToNextUpgrade = 10; 

        this.initInput();
    }

    initInput() {
        window.addEventListener('resize', () => {
            this.width = window.innerWidth; this.height = window.innerHeight;
            const dpr = window.devicePixelRatio || 1;
            this.canvas.width = this.width * dpr; this.canvas.height = this.height * dpr;
            this.canvas.style.width = `${this.width}px`; this.canvas.style.height = `${this.height}px`;
            this.ctx.scale(dpr, dpr);
        });
        window.addEventListener('mousemove', (e) => { this.mouseX = e.clientX; this.mouseY = e.clientY; });
        
        window.addEventListener('keydown', (e) => {
            if (e.target.tagName === 'INPUT') return;
            const key = e.key.toLowerCase();
            if (Object.values(window.gameSettings.keybinds).includes(key)) { e.preventDefault(); }
            this.keys[key] = true;
            
            if (this.isChoosingUpgrade) {
                if (key === '1' && this.currentUpgradeChoices[0]) this.selectUpgrade(0);
                if (key === '2' && this.currentUpgradeChoices[1]) this.selectUpgrade(1);
                if (key === '3' && this.currentUpgradeChoices[2]) this.selectUpgrade(2);
            }
        });
        
        window.addEventListener('keyup', (e) => { 
            if (e.target.tagName === 'INPUT') return;
            this.keys[e.key.toLowerCase()] = false; 
        });
    }

    getSafeSpawnPosition() {
        let x, y, isSafe = false;
        while (!isSafe) {
            x = Math.random() * this.worldSize; y = Math.random() * this.worldSize;
            if (!this.player || distance(x, y, this.player.x, this.player.y) > 1000) isSafe = true;
        }
        return { x, y };
    }

    spawnParticles(x, y, color, amount) {
        if (!window.gameSettings.particles) return;
        for (let i = 0; i < amount; i++) {
            this.particles.push(new Particle(x, y, color));
        }
    }

    grantAccountXP(baseAmount, enemyPoints = 0) {
        let multiplier = 1;
        if (enemyPoints > this.player.points) {
            multiplier = enemyPoints / Math.max(1, this.player.points);
        }
        multiplier = Math.min(multiplier, 5);
        
        let bonusFromScore = Math.floor(enemyPoints / 100); 
        const finalXP = Math.floor(baseAmount * multiplier) + bonusFromScore;
        
        window.globalAccountXP += finalXP;
        this.matchXPEarned += finalXP;
        this.checkAccountLevelUp();
    }

    checkAccountLevelUp() {
        let xpRequired = window.globalAccountLevel * 1000;
        let leveledUp = false;

        while (window.globalAccountXP >= xpRequired) {
            window.globalAccountLevel++;
            window.globalAccountXP -= xpRequired;
            xpRequired = window.globalAccountLevel * 1000;
            leveledUp = true;
        }

        if (leveledUp) {
            const notif = document.getElementById('account-level-notif');
            if (notif) {
                document.getElementById('account-notif-level-num').innerText = window.globalAccountLevel;
                notif.classList.add('show');
                if (this.accountLevelUpTimeout) clearTimeout(this.accountLevelUpTimeout);
                this.accountLevelUpTimeout = setTimeout(() => notif.classList.remove('show'), 4000);
            }
        }
    }

    start(playerClass) {
        if (this.animationId) {
            cancelAnimationFrame(this.animationId);
            this.animationId = null;
        }

        this.player = new Player(this.worldSize / 2, this.worldSize / 2, playerClass);
        this.bots = []; this.orbs = []; this.projectiles = []; this.particles = [];
        this.isGameOver = false;
        this.pointsToNextUpgrade = 10;
        this.matchStartTime = Date.now();
        this.matchXPEarned = 0; 
        
        this.distanceTraveled = 0;
        this.lastPlayerPos = { x: this.player.x, y: this.player.y };
        
        this.pendingUpgrades = 0;
        this.isChoosingUpgrade = false;
        document.getElementById('upgrade-ui').classList.add('hidden');
        document.getElementById('xp-bar').style.width = '0%';
        document.getElementById('level-display').innerText = '0 PTS';
        
        let matchSeed = Math.random();
        
        for(let i = 0; i < 35; i++) {
            const types = ['triangle', 'square', 'circle'];
            const type = types[Math.floor(Math.random()*3)];
            const spawn = this.getSafeSpawnPosition();
            
            let startingPts = 0;
            if (matchSeed > 0.9) { 
                startingPts = Math.random() < 0.2 ? Math.random() * 25000 : Math.random() * 1500;
            } else if (matchSeed < 0.4) { 
                startingPts = Math.random() * 80;
            } else { 
                startingPts = Math.random() < 0.1 ? Math.random() * 3000 : Math.random() * 300;
            }
            
            this.bots.push(new Bot(spawn.x, spawn.y, type, startingPts));
        }
        
        for(let i = 0; i < 300; i++) {
            this.orbs.push(new Orb(Math.random() * this.worldSize, Math.random() * this.worldSize, 'xp', 1, null, 0));
        }
        for(let i = 0; i < 40; i++) {
            this.orbs.push(new Orb(Math.random() * this.worldSize, Math.random() * this.worldSize, 'health', 1, null, 0));
        }

        this.lastTime = performance.now();
        this.lastFpsTime = performance.now();
        this.framesThisSecond = 0;
        this.loop(this.lastTime);
    }

    updateLeaderboard() {
        const allPlayers = [this.player, ...this.bots];
        allPlayers.sort((a, b) => b.points - a.points); 
        
        const list = document.getElementById('leaderboard-list');
        list.innerHTML = ''; 
        allPlayers.slice(0, 10).forEach((p, index) => {
            const li = document.createElement('li');
            li.innerText = `#${index + 1} ${p.name} - ${Math.floor(p.points)} Pts`;
            if (p === this.player) li.style.color = '#00ffcc';
            list.appendChild(li);
        });
    }

    showNextUpgrade() {
        if (this.pendingUpgrades <= 0) return;
        this.isChoosingUpgrade = true;
        this.currentUpgradeChoices = getWeightedUpgrades(this.player, 3);
        
        if (this.currentUpgradeChoices.length === 0) {
            this.pendingUpgrades = 0;
            this.isChoosingUpgrade = false;
            return;
        }

        for (let i = 0; i < 3; i++) {
            const choice = this.currentUpgradeChoices[i];
            const card = document.getElementById(`card-${i+1}`);
            if (choice && card) {
                const currentTier = this.player.upgrades[choice.id];
                document.getElementById(`title-${i+1}`).innerText = `${choice.title} [T${currentTier+1}]`;
                document.getElementById(`desc-${i+1}`).innerText = choice.desc;
                card.style.display = 'block';
            } else if (card) {
                card.style.display = 'none';
            }
        }
        document.getElementById('upgrade-ui').classList.remove('hidden');
    }

    selectUpgrade(index) {
        const choice = this.currentUpgradeChoices[index];
        this.player.applyUpgrade(choice.id);
        this.grantAccountXP(15); 
        document.getElementById('upgrade-ui').classList.add('hidden');
        this.isChoosingUpgrade = false;
        this.pendingUpgrades--;
        if (this.pendingUpgrades > 0) setTimeout(() => this.showNextUpgrade(), 200); 
    }

    triggerUpgradeReady() {
        const notif = document.getElementById('level-up-notif');
        if (notif) {
            notif.classList.add('show');
            if (this.levelUpTimeout) clearTimeout(this.levelUpTimeout);
            this.levelUpTimeout = setTimeout(() => notif.classList.remove('show'), 3000);
        }
        this.pendingUpgrades++;
        if (!this.isChoosingUpgrade) this.showNextUpgrade();
    }

    handleGameOver() {
        this.isGameOver = true;
        const timeAlive = Math.floor((Date.now() - this.matchStartTime) / 1000);
        this.grantAccountXP(timeAlive * 2);

        const allPlayers = [this.player, ...this.bots];
        allPlayers.sort((a, b) => b.points - a.points);
        const rank = allPlayers.indexOf(this.player) + 1;
        const totalPlayers = allPlayers.length;

        window.lastMatchStats = {
            kills: this.player.kills || 0,
            time: timeAlive || 0,
            points: Math.floor(this.player.points || 0),
            distance: Math.floor(this.distanceTraveled || 0),
            rank: rank || 0,
            totalPlayers: totalPlayers || 0,
            playerClass: this.player.type || 'Unknown' 
        };

        document.getElementById('go-points').innerText = Math.floor(this.player.points);
        document.getElementById('go-kills').innerText = this.player.kills;
        document.getElementById('go-time').innerText = `${timeAlive}s`;
        document.getElementById('go-xp').innerText = `+${this.matchXPEarned}`; 
        document.getElementById('game-over-screen').classList.remove('hidden');
    }

    update() {
        if (this.isGameOver) return; 

        let pointsGainedThisFrame = 0;

        this.frameCount++;
        if (this.frameCount % 30 === 0) this.updateLeaderboard(); 

        let dx = 0; let dy = 0;
        const binds = window.gameSettings.keybinds;

        if (this.keys[binds.up]) dy -= 1; 
        if (this.keys[binds.down]) dy += 1;
        if (this.keys[binds.left]) dx -= 1; 
        if (this.keys[binds.right]) dx += 1;
        
        if (this.keys[binds.dash]) {
            let preDashPts = this.player.points;
            this.player.dash(dx, dy);
            if (preDashPts > this.player.points) { 
                this.spawnParticles(this.player.x, this.player.y, '#ffffff', 8);
            }
            this.keys[binds.dash] = false; 
        }

        if (dx !== 0 || dy !== 0) {
            const length = Math.hypot(dx, dy);
            this.player.vx += (dx / length) * (this.player.speed * 0.2);
            this.player.vy += (dy / length) * (this.player.speed * 0.2);
        }

        const distMoved = Math.hypot(this.player.x - this.lastPlayerPos.x, this.player.y - this.lastPlayerPos.y);
        this.distanceTraveled += distMoved;
        this.lastPlayerPos.x = this.player.x;
        this.lastPlayerPos.y = this.player.y;

        this.player.angle = Math.atan2(this.mouseY - this.height / 2, this.mouseX - this.width / 2);
        this.player.update();

        for (let i = this.particles.length - 1; i >= 0; i--) {
            this.particles[i].update();
            if (this.particles[i].life <= 0) this.particles.splice(i, 1);
        }

        if (this.player.fireCooldown <= 0) {
            const totalShots = this.player.multiShot + 1;
            const spreadAngle = 0.2; 
            const startAngle = this.player.angle - (spreadAngle * (totalShots - 1)) / 2;
            
            for (let s = 0; s < totalShots; s++) {
                let finalAngle = startAngle + (s * spreadAngle);
                if (this.player.type === 'triangle') finalAngle += (Math.random() - 0.5) * 0.15;
                this.projectiles.push(new Projectile(this.player.x, this.player.y, finalAngle, this.player));
            }
            this.player.fireCooldown = this.player.fireRate;
        }

        if (this.player.missiles > 0) {
            if (this.player.missileCooldown <= 0) {
                this.projectiles.push(new Projectile(this.player.x, this.player.y, this.player.angle, this.player, true));
                this.player.missileCooldown = Math.max(20, 90 - (this.player.missiles * 15)); 
            }
            this.player.missileCooldown--;
        }

        const allPlayers = [this.player, ...this.bots];

        for (let i = this.bots.length - 1; i >= 0; i--) {
            const bot = this.bots[i];
            bot.updateBot(allPlayers);
            let enemyClose = false;
            for(let p of allPlayers) {
                if (p !== bot && distance(bot.x, bot.y, p.x, p.y) < 600) { enemyClose = true; break; }
            }
            
            if (enemyClose && bot.fireCooldown <= 0) {
                let totalShots = bot.multiShot + 1;
                let spreadAngle = 0.2; 
                let startAngle = bot.angle - (spreadAngle * (totalShots - 1)) / 2;
                
                for (let s = 0; s < totalShots; s++) {
                    let finalAngle = startAngle + (s * spreadAngle);
                    if (bot.type === 'triangle') finalAngle += (Math.random() - 0.5) * 0.15;
                    this.projectiles.push(new Projectile(bot.x, bot.y, finalAngle, bot));
                }
                bot.fireCooldown = bot.fireRate;
            }
            
            if (bot.missiles > 0) {
                if (bot.missileCooldown <= 0) {
                    this.projectiles.push(new Projectile(bot.x, bot.y, bot.angle, bot, true));
                    bot.missileCooldown = Math.max(20, 90 - (bot.missiles * 15)); 
                }
                bot.missileCooldown--;
            }

            bot.x = Math.max(0, Math.min(this.worldSize, bot.x)); bot.y = Math.max(0, Math.min(this.worldSize, bot.y));
        }

        const checkPiercing = (attacker, victim) => {
            if (attacker.piercing > 0 && attacker.spikeCooldown <= 0) {
                let angleToVictim = Math.atan2(victim.y - attacker.y, victim.x - attacker.x);
                let diff = angleToVictim - attacker.angle;
                
                while (diff > Math.PI) diff -= Math.PI * 2;
                while (diff < -Math.PI) diff += Math.PI * 2;
                
                if (Math.abs(diff) < Math.PI / 4) { 
                    victim.health -= attacker.piercing * 30; 
                    attacker.spikeCooldown = 30; 
                    this.spawnParticles(victim.x, victim.y, '#ff4444', 8);
                }
            }
        };

        for (let i = 0; i < allPlayers.length; i++) {
            for (let j = i + 1; j < allPlayers.length; j++) {
                const p1 = allPlayers[i]; const p2 = allPlayers[j];
                const dist = distance(p1.x, p1.y, p2.x, p2.y);
                const minDistance = p1.size + p2.size; 
                
                if (dist < minDistance && dist > 0) {
                    const overlap = minDistance - dist; const nx = (p1.x - p2.x) / dist; const ny = (p1.y - p2.y) / dist;
                    p1.x += nx * (overlap / 2); p1.y += ny * (overlap / 2);
                    p2.x -= nx * (overlap / 2); p2.y -= ny * (overlap / 2);

                    if (p1.spikes > 0 && p1.spikeCooldown <= 0) {
                        let dmg = p1.type === 'square' ? p1.spikes * 2.5 : p1.spikes * 5;
                        p2.health -= dmg; p1.spikeCooldown = 30; 
                        this.spawnParticles(p2.x, p2.y, '#ff4444', 5);
                    }
                    if (p2.spikes > 0 && p2.spikeCooldown <= 0) {
                        let dmg = p2.type === 'square' ? p2.spikes * 2.5 : p2.spikes * 5;
                        p1.health -= dmg; p2.spikeCooldown = 30;
                        this.spawnParticles(p1.x, p1.y, '#ff4444', 5);
                    }

                    checkPiercing(p1, p2);
                    checkPiercing(p2, p1);
                }
            }
        }

        allPlayers.forEach(p => {
            if (p.orbiters > 0) {
                let t = Date.now() / 500;
                for (let i = 0; i < p.orbiters; i++) {
                    let angle = t + (i / p.orbiters) * Math.PI * 2;
                    let ox = p.x + Math.cos(angle) * (p.size + 25);
                    let oy = p.y + Math.sin(angle) * (p.size + 25);
                    
                    allPlayers.forEach(target => {
                        if (p === target) return;
                        if (distance(ox, oy, target.x, target.y) < target.size + 6) {
                            target.health -= 0.5; 
                            if (Math.random() < 0.1) this.spawnParticles(ox, oy, '#a855f7', 1);
                        }
                    });
                }
            }
        });

        for (let i = this.projectiles.length - 1; i >= 0; i--) {
            const proj = this.projectiles[i];
            proj.update(allPlayers); 
            
            let hit = false;
            for (let j = allPlayers.length - 1; j >= 0; j--) {
                const target = allPlayers[j];
                if (proj.owner === target) continue; 
                if (distance(proj.x, proj.y, target.x, target.y) < target.size) {
                    target.health -= proj.damage;
                    hit = true;
                    this.spawnParticles(proj.x, proj.y, proj.color, 4);

                    if (target.health <= 0) {
                        this.spawnParticles(target.x, target.y, target.color, 20); 
                        
                        let totalTargetPoints = target.points;
                        let directReward = 0; 
                        let orbReward = Math.floor(totalTargetPoints * 0.75); 
                        
                        if (proj.owner === this.player) {
                            this.player.kills++;
                            this.grantAccountXP(50, totalTargetPoints);
                        } 

                        let orbsToSpawn = Math.min(orbReward, 20); 
                        if (orbsToSpawn > 0) {
                            let valuePerOrb = Math.max(1, Math.floor(orbReward / orbsToSpawn));
                            for (let o = 0; o < orbsToSpawn; o++) {
                                this.orbs.push(new Orb(target.x, target.y, 'xp', valuePerOrb, null, 180));
                            }
                        } else if (totalTargetPoints < 3) {
                            this.orbs.push(new Orb(target.x, target.y, 'xp', 1, null, 100));
                        }
                        
                        if (target !== this.player) {
                            this.bots.splice(this.bots.indexOf(target), 1);
                            const safePos = this.getSafeSpawnPosition();
                            this.bots.push(new Bot(safePos.x, safePos.y, ['triangle', 'square', 'circle'][Math.floor(Math.random()*3)]));
                        } else {
                            this.handleGameOver();
                        }
                    }
                    break;
                }
            }
            if (hit || proj.life <= 0) this.projectiles.splice(i, 1);
        }

        for (let i = this.orbs.length - 1; i >= 0; i--) {
            const orb = this.orbs[i];
            if (orb.lockoutTimer > 0) orb.lockoutTimer--;

            let collectedBy = null;

            let distP = distance(this.player.x, this.player.y, orb.x, orb.y);
            let canPlayerTouch = (orb.lockedOwner !== this.player || orb.lockoutTimer <= 0);
            
            if (distP < 150 && canPlayerTouch) { 
                orb.x += (this.player.x - orb.x) * 0.1; 
                orb.y += (this.player.y - orb.y) * 0.1; 
            }
            if (distP < this.player.size + orb.size && canPlayerTouch) {
                collectedBy = this.player;
            } else {
                for (let b of this.bots) {
                    let distB = distance(b.x, b.y, orb.x, orb.y);
                    let canBotTouch = (orb.lockedOwner !== b || orb.lockoutTimer <= 0);
                    
                    if (distB < 150 && canBotTouch) {
                        orb.x += (b.x - orb.x) * 0.1;
                        orb.y += (b.y - orb.y) * 0.1;
                    }
                    if (distB < b.size + orb.size && canBotTouch) {
                        collectedBy = b;
                        break;
                    }
                }
            }

            if (collectedBy) {
                if (orb.type === 'health') {
                    if (collectedBy.health < collectedBy.maxHealth) {
                        collectedBy.health = Math.min(collectedBy.maxHealth, collectedBy.health + orb.healAmount);
                    }
                    this.orbs.push(new Orb(Math.random() * this.worldSize, Math.random() * this.worldSize, 'health'));
                } else {
                    collectedBy.points += orb.value;
                    collectedBy.upgradeProgress += orb.value;
                    if (collectedBy === this.player) pointsGainedThisFrame += orb.value;
                }
                this.orbs.splice(i, 1);
            }
        }

        if (pointsGainedThisFrame > 0) {
            while (this.player.upgradeProgress >= this.pointsToNextUpgrade) {
                this.player.upgradeProgress -= this.pointsToNextUpgrade;
                this.player.upgradeCount++;
                this.pointsToNextUpgrade = Math.floor(this.pointsToNextUpgrade * 1.5); 
                this.triggerUpgradeReady();
            }
        }

        document.getElementById('level-display').innerText = `${Math.floor(this.player.points)} PTS`;
        document.getElementById('xp-bar').style.width = Math.min(100, (this.player.upgradeProgress / this.pointsToNextUpgrade) * 100) + '%';
    }

    draw() {
        this.ctx.fillStyle = '#111'; this.ctx.fillRect(0, 0, this.width, this.height);
        this.ctx.save();
        const camX = this.width / 2 - this.player.x; const camY = this.height / 2 - this.player.y;
        this.ctx.translate(camX, camY);
        
        this.ctx.strokeStyle = '#222'; this.ctx.lineWidth = 1; const gridSize = 100;
        const startX = Math.floor(this.player.x - this.width/2); const startY = Math.floor(this.player.y - this.height/2);
        this.ctx.beginPath();
        for (let x = startX - (startX % gridSize); x < startX + this.width + gridSize; x += gridSize) {
            this.ctx.moveTo(x, startY - gridSize); this.ctx.lineTo(x, startY + this.height + gridSize);
        }
        for (let y = startY - (startY % gridSize); y < startY + this.height + gridSize; y += gridSize) {
            this.ctx.moveTo(startX - gridSize, y); this.ctx.lineTo(startX + this.width + gridSize, y);
        }
        this.ctx.stroke();

        this.orbs.forEach(orb => orb.draw(this.ctx));
        this.particles.forEach(p => p.draw(this.ctx));
        this.projectiles.forEach(proj => proj.draw(this.ctx));
        this.bots.forEach(bot => bot.draw(this.ctx));
        if (!this.isGameOver) this.player.draw(this.ctx);

        this.ctx.restore();
    }

    loop(timestamp) {
        if (!this.isGameOver) {
            this.animationId = requestAnimationFrame((t) => this.loop(t));
        }

        if (window.gameSettings.showFps) {
            this.framesThisSecond++;
            if (timestamp - this.lastFpsTime >= 1000) {
                document.getElementById('fps-display').innerText = `${this.framesThisSecond} FPS`;
                this.framesThisSecond = 0;
                this.lastFpsTime = timestamp;
            }
        }

        const elapsed = timestamp - this.lastTime;
        
        if (elapsed >= this.fpsInterval) {
            this.lastTime = timestamp - (elapsed % this.fpsInterval);
            this.update();
            this.draw();
        }
    }
}