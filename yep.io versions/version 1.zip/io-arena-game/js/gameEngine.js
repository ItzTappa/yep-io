import { Player, Bot, Orb, Projectile } from './entities.js';
import { distance } from './utils.js';

export class GameEngine {
    constructor(canvas) {
        this.canvas = canvas; this.ctx = canvas.getContext('2d');
        this.width = window.innerWidth; this.height = window.innerHeight;
        const dpr = window.devicePixelRatio || 1;
        this.canvas.width = this.width * dpr; this.canvas.height = this.height * dpr;
        this.canvas.style.width = `${this.width}px`; this.canvas.style.height = `${this.height}px`;
        this.ctx.scale(dpr, dpr);

        this.worldSize = 4000;
        this.player = null; this.bots = []; this.orbs = []; this.projectiles = []; 
        this.mouseX = this.width / 2; this.mouseY = this.height / 2;
        this.keys = {}; this.frameCount = 0; 
        
        this.levelUpTimeout = null; 
        this.accountLevelUpTimeout = null; 
        this.animationId = null; 
        
        this.fpsInterval = 1000 / 60; 
        this.lastTime = 0;
        this.lastFpsTime = performance.now(); 
        this.framesThisSecond = 0;

        this.isGameOver = false;
        this.matchStartTime = 0;
        this.matchXPEarned = 0; 
        
        this.distanceTraveled = 0;
        this.lastPlayerPos = { x: 0, y: 0 };

        this.pendingUpgrades = 0; 
        this.currentUpgradeChoices = [];
        this.isChoosingUpgrade = false;
        this.pointsToNextUpgrade = 10; 

        this.upgradePool = [
            { id: 'speed', title: 'Thrusters', desc: '+Speed' },
            { id: 'damage', title: 'Heavy Caliber', desc: '+Damage' },
            { id: 'fireRate', title: 'Rapid Loader', desc: '+Fire Rate' },
            { id: 'health', title: 'Reinforced Hull', desc: '+Max Health' }
        ];

        this.initInput();
    }

    initInput() {
        window.addEventListener('resize', () => {
            this.width = window.innerWidth; this.height = window.innerHeight;
            const dpr = window.devicePixelRatio || 1;
            this.canvas.width = this.width * dpr; this.canvas.height = this.height * dpr;
            this.canvas.style.width = `${this.width}px`; this.canvas.style.height = `${this.height}px`;
            this.ctx.scale(dpr, dpr);
        });
        window.addEventListener('mousemove', (e) => { this.mouseX = e.clientX; this.mouseY = e.clientY; });
        
        window.addEventListener('keydown', (e) => {
            if (e.target.tagName === 'INPUT') return;
            const key = e.key.toLowerCase();
            
            if (Object.values(window.gameSettings.keybinds).includes(key)) {
                e.preventDefault(); 
            }

            this.keys[key] = true;
            
            if (this.isChoosingUpgrade) {
                if (key === '1' && this.currentUpgradeChoices[0]) this.selectUpgrade(0);
                if (key === '2' && this.currentUpgradeChoices[1]) this.selectUpgrade(1);
                if (key === '3' && this.currentUpgradeChoices[2]) this.selectUpgrade(2);
            }
        });
        
        window.addEventListener('keyup', (e) => { 
            if (e.target.tagName === 'INPUT') return;
            this.keys[e.key.toLowerCase()] = false; 
        });
    }

    getSafeSpawnPosition() {
        let x, y, isSafe = false;
        while (!isSafe) {
            x = Math.random() * this.worldSize; y = Math.random() * this.worldSize;
            if (!this.player || distance(x, y, this.player.x, this.player.y) > 1000) isSafe = true;
        }
        return { x, y };
    }

    grantAccountXP(baseAmount, enemyPoints = 0) {
        let multiplier = 1;
        if (enemyPoints > this.player.points) {
            multiplier = enemyPoints / Math.max(1, this.player.points);
        }
        multiplier = Math.min(multiplier, 5);
        
        const finalXP = Math.floor(baseAmount * multiplier);
        window.globalAccountXP += finalXP;
        this.matchXPEarned += finalXP;
        this.checkAccountLevelUp();
    }

    checkAccountLevelUp() {
        let xpRequired = window.globalAccountLevel * 1000;
        let leveledUp = false;

        while (window.globalAccountXP >= xpRequired) {
            window.globalAccountLevel++;
            window.globalAccountXP -= xpRequired;
            xpRequired = window.globalAccountLevel * 1000;
            leveledUp = true;
        }

        if (leveledUp) {
            const notif = document.getElementById('account-level-notif');
            if (notif) {
                document.getElementById('account-notif-level-num').innerText = window.globalAccountLevel;
                notif.classList.add('show');
                if (this.accountLevelUpTimeout) clearTimeout(this.accountLevelUpTimeout);
                this.accountLevelUpTimeout = setTimeout(() => notif.classList.remove('show'), 4000);
            }
        }
    }

    start(playerClass) {
        if (this.animationId) {
            cancelAnimationFrame(this.animationId);
            this.animationId = null;
        }

        this.player = new Player(this.worldSize / 2, this.worldSize / 2, playerClass);
        this.bots = []; this.orbs = []; this.projectiles = [];
        this.isGameOver = false;
        this.pointsToNextUpgrade = 10;
        this.matchStartTime = Date.now();
        this.matchXPEarned = 0; 
        
        this.distanceTraveled = 0;
        this.lastPlayerPos = { x: this.player.x, y: this.player.y };
        
        this.pendingUpgrades = 0;
        this.isChoosingUpgrade = false;
        document.getElementById('upgrade-ui').classList.add('hidden');
        document.getElementById('xp-bar').style.width = '0%';
        document.getElementById('level-display').innerText = '0 PTS';
        
        for(let i = 0; i < 35; i++) {
            const types = ['triangle', 'square', 'circle'];
            const spawn = this.getSafeSpawnPosition();
            this.bots.push(new Bot(spawn.x, spawn.y, types[Math.floor(Math.random()*3)]));
        }
        
        // --- NEW: SPAWN XP ORBS AND HEALTH ORBS ---
        for(let i = 0; i < 300; i++) {
            this.orbs.push(new Orb(Math.random() * this.worldSize, Math.random() * this.worldSize, 'xp'));
        }
        // Spawn 40 health orbs scattered across the large map
        for(let i = 0; i < 40; i++) {
            this.orbs.push(new Orb(Math.random() * this.worldSize, Math.random() * this.worldSize, 'health'));
        }

        this.lastTime = performance.now();
        this.lastFpsTime = performance.now();
        this.framesThisSecond = 0;
        this.loop(this.lastTime);
    }

    updateLeaderboard() {
        const allPlayers = [this.player, ...this.bots];
        allPlayers.sort((a, b) => b.points - a.points); 
        
        const list = document.getElementById('leaderboard-list');
        list.innerHTML = ''; 
        allPlayers.slice(0, 10).forEach((p, index) => {
            const li = document.createElement('li');
            li.innerText = `#${index + 1} ${p.name} - ${p.points} Pts`;
            if (p === this.player) li.style.color = '#00ffcc';
            list.appendChild(li);
        });
    }

    spawnOrbs(x, y, amount) {
        // Exploding enemies only drop XP orbs
        for(let i=0; i < amount; i++) this.orbs.push(new Orb(x, y, 'xp'));
    }

    showNextUpgrade() {
        if (this.pendingUpgrades <= 0) return;
        this.isChoosingUpgrade = true;
        this.currentUpgradeChoices = [];
        
        let available = this.upgradePool.filter(upg => this.player.upgrades[upg.id] < this.player.maxUpgradeTier);
        if (available.length === 0) {
            this.pendingUpgrades = 0;
            this.isChoosingUpgrade = false;
            return;
        }

        available.sort(() => 0.5 - Math.random());
        this.currentUpgradeChoices = available.slice(0, 3);

        for (let i = 0; i < 3; i++) {
            const choice = this.currentUpgradeChoices[i];
            const card = document.getElementById(`card-${i+1}`);
            if (choice && card) {
                const currentTier = this.player.upgrades[choice.id];
                document.getElementById(`title-${i+1}`).innerText = `${choice.title} [T${currentTier+1}]`;
                document.getElementById(`desc-${i+1}`).innerText = choice.desc;
                card.style.display = 'block';
            } else if (card) {
                card.style.display = 'none';
            }
        }
        document.getElementById('upgrade-ui').classList.remove('hidden');
    }

    selectUpgrade(index) {
        const choice = this.currentUpgradeChoices[index];
        this.player.applyUpgrade(choice.id);
        this.grantAccountXP(15); 
        document.getElementById('upgrade-ui').classList.add('hidden');
        this.isChoosingUpgrade = false;
        this.pendingUpgrades--;
        if (this.pendingUpgrades > 0) setTimeout(() => this.showNextUpgrade(), 200); 
    }

    triggerUpgradeReady() {
        const notif = document.getElementById('level-up-notif');
        if (notif) {
            notif.classList.add('show');
            if (this.levelUpTimeout) clearTimeout(this.levelUpTimeout);
            this.levelUpTimeout = setTimeout(() => notif.classList.remove('show'), 3000);
        }
        this.pendingUpgrades++;
        if (!this.isChoosingUpgrade) this.showNextUpgrade();
    }

    handleGameOver() {
        this.isGameOver = true;
        const timeAlive = Math.floor((Date.now() - this.matchStartTime) / 1000);
        this.grantAccountXP(timeAlive * 2);

        window.lastMatchStats = {
            kills: this.player.kills,
            time: timeAlive,
            points: this.player.points,
            distance: Math.floor(this.distanceTraveled)
        };

        document.getElementById('go-points').innerText = this.player.points;
        document.getElementById('go-kills').innerText = this.player.kills;
        document.getElementById('go-time').innerText = `${timeAlive}s`;
        document.getElementById('go-xp').innerText = `+${this.matchXPEarned}`; 
        document.getElementById('game-over-screen').classList.remove('hidden');
    }

    update() {
        if (this.isGameOver) return; 

        this.frameCount++;
        if (this.frameCount % 30 === 0) this.updateLeaderboard(); 

        let dx = 0; let dy = 0;
        const binds = window.gameSettings.keybinds;

        if (this.keys[binds.up]) dy -= 1; 
        if (this.keys[binds.down]) dy += 1;
        if (this.keys[binds.left]) dx -= 1; 
        if (this.keys[binds.right]) dx += 1;
        
        if (this.keys[binds.dash]) {
            this.player.dash(dx, dy);
            this.keys[binds.dash] = false; 
        }

        if (dx !== 0 || dy !== 0) {
            const length = Math.hypot(dx, dy);
            this.player.vx += (dx / length) * (this.player.speed * 0.2);
            this.player.vy += (dy / length) * (this.player.speed * 0.2);
        }

        const distMoved = Math.hypot(this.player.x - this.lastPlayerPos.x, this.player.y - this.lastPlayerPos.y);
        this.distanceTraveled += distMoved;
        this.lastPlayerPos.x = this.player.x;
        this.lastPlayerPos.y = this.player.y;

        this.player.angle = Math.atan2(this.mouseY - this.height / 2, this.mouseX - this.width / 2);
        this.player.update();

        if (this.player.fireCooldown <= 0) {
            this.projectiles.push(new Projectile(this.player.x, this.player.y, this.player.angle, this.player));
            this.player.fireCooldown = this.player.fireRate;
        }

        const allPlayers = [this.player, ...this.bots];

        for (let i = this.bots.length - 1; i >= 0; i--) {
            const bot = this.bots[i];
            bot.updateBot(allPlayers);
            let enemyClose = false;
            for(let p of allPlayers) {
                if (p !== bot && distance(bot.x, bot.y, p.x, p.y) < 600) { enemyClose = true; break; }
            }
            if (enemyClose && bot.fireCooldown <= 0) {
                this.projectiles.push(new Projectile(bot.x, bot.y, bot.angle, bot));
                bot.fireCooldown = bot.fireRate;
            }
            bot.x = Math.max(0, Math.min(this.worldSize, bot.x)); bot.y = Math.max(0, Math.min(this.worldSize, bot.y));
        }

        for (let i = 0; i < allPlayers.length; i++) {
            for (let j = i + 1; j < allPlayers.length; j++) {
                const p1 = allPlayers[i]; const p2 = allPlayers[j];
                const dist = distance(p1.x, p1.y, p2.x, p2.y);
                const minDistance = p1.size + p2.size; 
                if (dist < minDistance && dist > 0) {
                    const overlap = minDistance - dist; const nx = (p1.x - p2.x) / dist; const ny = (p1.y - p2.y) / dist;
                    p1.x += nx * (overlap / 2); p1.y += ny * (overlap / 2);
                    p2.x -= nx * (overlap / 2); p2.y -= ny * (overlap / 2);
                }
            }
        }

        for (let i = this.projectiles.length - 1; i >= 0; i--) {
            const proj = this.projectiles[i];
            proj.update();
            let hit = false;
            for (let j = allPlayers.length - 1; j >= 0; j--) {
                const target = allPlayers[j];
                if (proj.owner === target) continue; 
                if (distance(proj.x, proj.y, target.x, target.y) < target.size) {
                    target.health -= proj.damage;
                    hit = true;
                    if (target.health <= 0) {
                        const orbsToDrop = 5 + Math.floor(target.points * 0.5);
                        this.spawnOrbs(target.x, target.y, Math.min(orbsToDrop, 30)); 
                        if (proj.owner === this.player) {
                            this.player.kills++;
                            this.grantAccountXP(50, target.points);
                        }
                        if (target !== this.player) {
                            this.bots.splice(this.bots.indexOf(target), 1);
                            const safePos = this.getSafeSpawnPosition();
                            this.bots.push(new Bot(safePos.x, safePos.y, ['triangle', 'square', 'circle'][Math.floor(Math.random()*3)]));
                        } else {
                            this.handleGameOver();
                        }
                    }
                    break;
                }
            }
            if (hit || proj.life <= 0) this.projectiles.splice(i, 1);
        }

        // --- NEW: COLLECTION LOGIC FOR HEALTH & XP ORBS ---
        let pointsGainedThisFrame = 0;
        for (let i = this.orbs.length - 1; i >= 0; i--) {
            const orb = this.orbs[i];
            const dist = distance(this.player.x, this.player.y, orb.x, orb.y);
            
            if (dist < 150) { 
                orb.x += (this.player.x - orb.x) * 0.1; 
                orb.y += (this.player.y - orb.y) * 0.1; 
            }
            
            if (dist < this.player.size + orb.size) {
                if (orb.type === 'health') {
                    // Only heal if they are missing health
                    if (this.player.health < this.player.maxHealth) {
                        this.player.health = Math.min(this.player.maxHealth, this.player.health + orb.healAmount);
                    }
                    // Regardless of if they needed it, consume it and spawn a new one globally
                    this.orbs.push(new Orb(Math.random() * this.worldSize, Math.random() * this.worldSize, 'health'));
                } else {
                    pointsGainedThisFrame++;
                }
                
                this.orbs.splice(i, 1);
            }
        }

        if (pointsGainedThisFrame > 0) {
            this.player.points += pointsGainedThisFrame;
            this.player.upgradeProgress += pointsGainedThisFrame; 
            document.getElementById('level-display').innerText = `${this.player.points} PTS`;
            
            while (this.player.upgradeProgress >= this.pointsToNextUpgrade) {
                this.player.upgradeProgress -= this.pointsToNextUpgrade;
                this.player.upgradeCount++;
                this.pointsToNextUpgrade = Math.floor(this.pointsToNextUpgrade * 1.5); 
                this.triggerUpgradeReady();
            }
            document.getElementById('xp-bar').style.width = Math.min(100, (this.player.upgradeProgress / this.pointsToNextUpgrade) * 100) + '%';
        }
    }

    draw() {
        this.ctx.fillStyle = '#111'; this.ctx.fillRect(0, 0, this.width, this.height);
        this.ctx.save();
        const camX = this.width / 2 - this.player.x; const camY = this.height / 2 - this.player.y;
        this.ctx.translate(camX, camY);
        this.ctx.strokeStyle = '#222'; this.ctx.lineWidth = 1; const gridSize = 100;
        const startX = Math.floor(this.player.x - this.width/2); const startY = Math.floor(this.player.y - this.height/2);
        this.ctx.beginPath();
        for (let x = startX - (startX % gridSize); x < startX + this.width + gridSize; x += gridSize) {
            this.ctx.moveTo(x, startY - gridSize); this.ctx.lineTo(x, startY + this.height + gridSize);
        }
        for (let y = startY - (startY % gridSize); y < startY + this.height + gridSize; y += gridSize) {
            this.ctx.moveTo(startX - gridSize, y); this.ctx.lineTo(startX + this.width + gridSize, y);
        }
        this.ctx.stroke();

        this.orbs.forEach(orb => orb.draw(this.ctx));
        this.projectiles.forEach(proj => proj.draw(this.ctx));
        this.bots.forEach(bot => bot.draw(this.ctx));
        if (!this.isGameOver) this.player.draw(this.ctx);

        this.ctx.restore();
    }

    loop(timestamp) {
        if (!this.isGameOver) {
            this.animationId = requestAnimationFrame((t) => this.loop(t));
        }

        if (window.gameSettings.showFps) {
            this.framesThisSecond++;
            if (timestamp - this.lastFpsTime >= 1000) {
                document.getElementById('fps-display').innerText = `${this.framesThisSecond} FPS`;
                this.framesThisSecond = 0;
                this.lastFpsTime = timestamp;
            }
        }

        const elapsed = timestamp - this.lastTime;
        
        if (elapsed >= this.fpsInterval) {
            this.lastTime = timestamp - (elapsed % this.fpsInterval);
            this.update();
            this.draw();
        }
    }
}