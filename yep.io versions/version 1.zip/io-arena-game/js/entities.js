import { distance } from './utils.js';

export class Entity {
    constructor(x, y, type) {
        this.x = x; this.y = y; this.type = type;
        this.vx = 0; this.vy = 0; this.angle = 0;
        this.color = `hsl(${Math.random() * 360}, 80%, 60%)`;
        
        this.points = 0;
        this.upgradeProgress = 0; 
        this.kills = 0;
        this.upgradeCount = 0; 
        
        this.dashCooldown = 0;
        this.dashTimer = 0;
        this.trail = []; 

        if (type === 'circle') {
            this.speed = 6.5; this.size = 20; this.maxHealth = 100;
            this.fireRate = 25; this.baseDamage = 15;
            this.dashMaxCooldown = 120; 
        } else if (type === 'square') {
            this.speed = 4.5; this.size = 28; this.maxHealth = 180;
            this.fireRate = 45; this.baseDamage = 28;
            this.dashMaxCooldown = 180; 
        } else if (type === 'triangle') {
            this.speed = 8.5; this.size = 20; this.maxHealth = 70;
            this.fireRate = 12; this.baseDamage = 8;
            this.dashMaxCooldown = 90; 
        }
        
        this.health = this.maxHealth;
        this.fireCooldown = 0;
        this.name = "Player";
    }

    dash(dx, dy) {
        if (this.dashCooldown <= 0) {
            this.dashCooldown = this.dashMaxCooldown;
            this.dashTimer = 10; 
            
            let length = Math.hypot(dx, dy);
            if (length === 0) {
                dx = Math.cos(this.angle);
                dy = Math.sin(this.angle);
                length = 1;
            }
            
            this.vx += (dx / length) * (this.speed * 4);
            this.vy += (dy / length) * (this.speed * 4);
        }
    }

    update() {
        this.x += this.vx; this.y += this.vy;
        this.vx *= 0.85; this.vy *= 0.85; 
        
        if (this.fireCooldown > 0) this.fireCooldown--;
        if (this.dashCooldown > 0) this.dashCooldown--;
        
        if (this.dashTimer > 0) {
            this.dashTimer--;
            // By default, trailing color matches body color
            this.trail.push({ x: this.x, y: this.y, angle: this.angle, alpha: 0.5, color: this.color });
        }
        for (let i = this.trail.length - 1; i >= 0; i--) {
            this.trail[i].alpha -= 0.05;
            if (this.trail[i].alpha <= 0) this.trail.splice(i, 1);
        }
    }

    draw(ctx) {
        this.trail.forEach(t => {
            ctx.save();
            ctx.translate(t.x, t.y); ctx.rotate(t.angle);
            ctx.fillStyle = t.color; 
            ctx.globalAlpha = t.alpha;
            
            ctx.beginPath();
            if (this.type === 'circle') { ctx.arc(0, 0, this.size, 0, Math.PI * 2); ctx.fill(); } 
            else if (this.type === 'square') { ctx.fillRect(-this.size/2, -this.size/2, this.size, this.size); } 
            else if (this.type === 'triangle') {
                ctx.moveTo(this.size, 0); ctx.lineTo(-this.size / 2, -this.size * 0.866);
                ctx.lineTo(-this.size / 2, this.size * 0.866); ctx.closePath(); ctx.fill();
            }
            ctx.restore();
        });

        ctx.save();
        ctx.translate(this.x, this.y); ctx.rotate(this.angle);
        ctx.fillStyle = this.color; 
        
        if (window.gameSettings.highQuality) {
            ctx.shadowBlur = 15; 
            ctx.shadowColor = this.color;
        } else {
            ctx.shadowBlur = 0;
        }

        ctx.beginPath();
        if (this.type === 'circle') { ctx.arc(0, 0, this.size, 0, Math.PI * 2); ctx.fill(); } 
        else if (this.type === 'square') { ctx.fillRect(-this.size/2, -this.size/2, this.size, this.size); } 
        else if (this.type === 'triangle') {
            ctx.moveTo(this.size, 0); ctx.lineTo(-this.size / 2, -this.size * 0.866);
            ctx.lineTo(-this.size / 2, this.size * 0.866); ctx.closePath(); ctx.fill();
        }
        ctx.restore();

        if (window.gameSettings.showNames) {
            ctx.fillStyle = 'white'; ctx.font = 'bold 12px sans-serif'; ctx.textAlign = 'center';
            if (window.gameSettings.highQuality) {
                ctx.shadowBlur = 2; ctx.shadowColor = 'black';
            }
            ctx.fillText(this.name, this.x, this.y - this.size - 15);
            ctx.shadowBlur = 0; 
        }

        if (this.health < this.maxHealth) {
            ctx.fillStyle = 'rgba(255, 0, 0, 0.7)'; ctx.fillRect(this.x - 20, this.y + this.size + 10, 40, 5);
            ctx.fillStyle = '#00ffcc'; ctx.fillRect(this.x - 20, this.y + this.size + 10, 40 * (this.health / this.maxHealth), 5);
        }

        ctx.fillStyle = 'rgba(255, 255, 255, 0.2)'; 
        ctx.fillRect(this.x - 20, this.y + this.size + 17, 40, 3);
        if (this.dashCooldown <= 0) {
            ctx.fillStyle = '#facc15'; 
            ctx.fillRect(this.x - 20, this.y + this.size + 17, 40, 3);
        } else {
            ctx.fillStyle = '#ffffff'; 
            const pct = 1 - (this.dashCooldown / this.dashMaxCooldown);
            ctx.fillRect(this.x - 20, this.y + this.size + 17, 40 * pct, 3);
        }
    }
}

// --- NEW: PLAYER WITH COSMETICS APPLIED ---
export class Player extends Entity {
    constructor(x, y, type, name = "YOU") {
        super(x, y, type);
        this.name = name;
        this.upgrades = { speed: 0, damage: 0, fireRate: 0, health: 0 };
        this.maxUpgradeTier = 5; 

        // Read the globally equipped items
        this.equipped = window.equippedItems || { Skin: null, Trail: null, Banner: null, Color: null };

        // Apply Color Cosmetic
        if (this.equipped.Color) {
            const dbColor = window.ITEMS_DB[this.equipped.Color].value;
            if (dbColor === 'gold') this.color = '#facc15'; 
        } else {
            this.color = '#00ffcc'; 
        }

        // Apply Banner Cosmetic (Emoji next to name)
        if (this.equipped.Banner) {
            this.name = `${window.ITEMS_DB[this.equipped.Banner].value} ${this.name}`;
        }
    }

    applyUpgrade(upgradeId) {
        if (this.upgrades[upgradeId] >= this.maxUpgradeTier) return; 
        this.upgrades[upgradeId]++;
        
        if (upgradeId === 'speed') this.speed += 0.8;
        else if (upgradeId === 'damage') this.baseDamage += 5;
        else if (upgradeId === 'fireRate') this.fireRate = Math.max(5, this.fireRate - 3); 
        else if (upgradeId === 'health') { this.maxHealth += 25; this.health += 25; }
    }

    update() {
        super.update();

        // Apply Trail Cosmetic (Intercepts the super class trail push and changes its color)
        if (this.dashTimer > 0 && this.trail.length > 0) {
            if (this.equipped.Trail) {
                this.trail[this.trail.length - 1].color = window.ITEMS_DB[this.equipped.Trail].value;
            }
        }
    }

    draw(ctx) {
        // Run standard Entity drawing logic (Base shape, trail, UI bars)
        super.draw(ctx);

        // --- DRAW ADVANCED SKINS ON TOP ---
        if (this.equipped.Skin) {
            const skinType = window.ITEMS_DB[this.equipped.Skin].value;
            
            ctx.save();
            ctx.translate(this.x, this.y); 
            ctx.rotate(this.angle);
            
            if (skinType === 'neon') {
                ctx.fillStyle = '#ffffff';
                if (window.gameSettings.highQuality) {
                    ctx.shadowBlur = 15; ctx.shadowColor = '#ffffff';
                }
            } else if (skinType === 'dark') {
                ctx.fillStyle = '#111111';
                ctx.lineWidth = 3; ctx.strokeStyle = '#a855f7'; 
                ctx.stroke();
            } else if (skinType === 'gladiator') {
                ctx.fillStyle = '#9ca3af'; // metallic silver
                ctx.lineWidth = 2; ctx.strokeStyle = '#ffffff'; 
                ctx.stroke();
            }

            // Draw a smaller inner core to represent the skin
            ctx.beginPath();
            const innerSize = this.size * 0.5; 
            if (this.type === 'circle') { ctx.arc(0, 0, innerSize, 0, Math.PI * 2); ctx.fill(); } 
            else if (this.type === 'square') { ctx.fillRect(-innerSize/2, -innerSize/2, innerSize, innerSize); } 
            else if (this.type === 'triangle') {
                ctx.moveTo(innerSize, 0); ctx.lineTo(-innerSize / 2, -innerSize * 0.866);
                ctx.lineTo(-innerSize / 2, innerSize * 0.866); ctx.closePath(); ctx.fill();
            }
            ctx.restore();
        }
    }
}

export class Bot extends Entity {
    constructor(x, y, type) {
        super(x, y, type);
        this.targetX = x; this.targetY = y; this.changeTargetTimer = 0;
        
        const names = ['OrbHunter', 'NovaStrike', 'PixelSlayer', 'GhostBlade', 'RogueBot', 'Vanguard', 'Titan', 'Apex'];
        this.name = names[Math.floor(Math.random() * names.length)] + Math.floor(Math.random() * 99);
        
        this.upgradeCount = Math.floor(Math.random() * 10);
        this.points = this.upgradeCount * 25; 
        this.maxHealth += (this.upgradeCount * 10);
        this.health = this.maxHealth;
    }

    updateBot(allPlayers) {
        this.changeTargetTimer--;
        let nearestEnemy = null; let minDist = 600;

        allPlayers.forEach(p => {
            if (p === this) return;
            const dist = distance(this.x, this.y, p.x, p.y);
            if (dist < minDist) { minDist = dist; nearestEnemy = p; }
        });

        if (nearestEnemy) {
            this.angle = Math.atan2(nearestEnemy.y - this.y, nearestEnemy.x - this.x);
            const dx = nearestEnemy.x - this.x; const dy = nearestEnemy.y - this.y;
            
            if (minDist > 100 && minDist < 400 && Math.random() < 0.02) {
                this.dash(dx, dy);
            }

            if (minDist > 300) { this.vx += (dx / minDist) * (this.speed * 0.15); this.vy += (dy / minDist) * (this.speed * 0.15); } 
            else if (minDist < 200) { this.vx -= (dx / minDist) * (this.speed * 0.15); this.vy -= (dy / minDist) * (this.speed * 0.15); }
        } else if (this.changeTargetTimer <= 0) {
            this.targetX = this.x + (Math.random() - 0.5) * 800; this.targetY = this.y + (Math.random() - 0.5) * 800;
            this.changeTargetTimer = 60 + Math.random() * 60; 
            this.angle = Math.atan2(this.targetY - this.y, this.targetX - this.x);
            const dx = this.targetX - this.x; const dy = this.targetY - this.y; const dist = Math.hypot(dx, dy);
            if (dist > 10) { this.vx += (dx / dist) * (this.speed * 0.10); this.vy += (dy / dist) * (this.speed * 0.10); }
        }
        super.update();
    }
}

export class Projectile {
    constructor(x, y, angle, owner) {
        this.x = x + Math.cos(angle) * (owner.size + 5); this.y = y + Math.sin(angle) * (owner.size + 5); 
        this.angle = angle; this.owner = owner; this.speed = 15;
        this.damage = owner.baseDamage; 
        this.life = 60; this.color = owner.color;
    }
    update() { this.x += Math.cos(this.angle) * this.speed; this.y += Math.sin(this.angle) * this.speed; this.life--; }
    draw(ctx) {
        ctx.save(); ctx.translate(this.x, this.y); ctx.rotate(this.angle);
        ctx.fillStyle = '#fff'; 
        if (window.gameSettings.highQuality) { ctx.shadowBlur = 10; ctx.shadowColor = this.color; } 
        else { ctx.shadowBlur = 0; }
        ctx.fillRect(-10, -3, 20, 6); ctx.restore();
    }
}

export class Orb {
    constructor(x, y, type = 'xp') {
        this.x = x + (Math.random() - 0.5) * 40; 
        this.y = y + (Math.random() - 0.5) * 40;
        this.type = type;
        
        if (this.type === 'health') {
            this.size = 8; 
            this.color = '#3b82f6'; 
            this.healAmount = 30; 
        } else {
            this.size = 5; 
            this.color = '#facc15'; 
        }
    }
    draw(ctx) {
        ctx.save(); ctx.translate(this.x, this.y); ctx.fillStyle = this.color;
        if (window.gameSettings.highQuality) { ctx.shadowBlur = 10; ctx.shadowColor = this.color; } 
        else { ctx.shadowBlur = 0; }
        ctx.beginPath(); ctx.arc(0, 0, this.size, 0, Math.PI * 2); ctx.fill(); ctx.restore();
    }
}