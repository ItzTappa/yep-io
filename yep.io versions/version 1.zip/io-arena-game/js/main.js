import { GameEngine } from './gameEngine.js';

let selectedClass = 'triangle';

window.globalAccountXP = 0;
window.globalAccountLevel = 1;

window.gameSettings = { 
    highQuality: true, showNames: true, showFps: false,
    keybinds: { up: 'w', down: 's', left: 'a', right: 'd', dash: ' ' }
};

window.hourlyStats = { kills: 0, time: 0, points: 0, distance: 0 };
let currentShopHour = new Date().getHours();
window.claimedItems = {}; 

// NEW: Global Tracker for equipped items
window.equippedItems = { Skin: null, Trail: null, Banner: null, Color: null };

const RARITY_COLORS = { 1: '#a0a0a0', 2: '#22c55e', 3: '#3b82f6', 4: '#a855f7', 5: '#f97316' };

// NEW: Central Item Database so the Locker and Entities can read cosmetic data
window.ITEMS_DB = {
    // Season Items
    's_banner': { id: 's_banner', name: 'Veteran', category: 'Banner', icon: '🏴', color: RARITY_COLORS[2], req: 10, value: '🏴' },
    's_trail': { id: 's_trail', name: 'Plasma', category: 'Trail', icon: '☄️', color: RARITY_COLORS[3], req: 25, value: '#00ffff' },
    's_skin1': { id: 's_skin1', name: 'Neon Striker', category: 'Skin', icon: '✨', color: RARITY_COLORS[4], req: 35, value: 'neon' },
    's_skin2': { id: 's_skin2', name: 'Dark Matter', category: 'Skin', icon: '🌌', color: RARITY_COLORS[5], req: 50, value: 'dark' },
    
    // Main Store Fixed IDs (so you keep them when the hour changes)
    'm_skin': { id: 'm_skin', name: 'Gladiator', category: 'Skin', icon: '⚔️', type: 'kills', req: 40, label: 'Kills', value: 'gladiator' },
    'm_banner': { id: 'm_banner', name: 'Marathon', category: 'Banner', icon: '🏃', type: 'distance', req: 120000, label: 'Dist.', value: '🏃' },
    'm_trail': { id: 'm_trail', name: 'Survivor', category: 'Trail', icon: '⏱️', type: 'time', req: 400, label: 'Secs', value: '#22c55e' },
    'm_color': { id: 'm_color', name: 'High Roller', category: 'Color', icon: '💎', type: 'points', req: 5000, label: 'Pts', value: 'gold' }
};

function getRarityScore(type, req) {
    if (type === 'kills') { if (req < 15) return 1; if (req < 30) return 2; if (req < 50) return 3; if (req < 80) return 4; return 5; }
    if (type === 'distance') { if (req < 15000) return 1; if (req < 30000) return 2; if (req < 60000) return 3; if (req < 100000) return 4; return 5; }
    if (type === 'time') { if (req < 300) return 1; if (req < 600) return 2; if (req < 1200) return 3; if (req < 2400) return 4; return 5; }
    if (type === 'points') { if (req < 500) return 1; if (req < 1500) return 2; if (req < 3000) return 3; if (req < 6000) return 4; return 5; }
    return 1;
}

const canvas = document.getElementById('gameCanvas');
const game = new GameEngine(canvas);

document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
        e.target.classList.add('active');
        document.getElementById(e.target.dataset.target).classList.add('active');
        
        if (e.target.dataset.target === 'season') renderSeasonStore();
        if (e.target.dataset.target === 'store') renderMainStore();
        if (e.target.dataset.target === 'locker') renderLocker();
    });
});

document.querySelectorAll('.class-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
        document.querySelectorAll('.class-btn').forEach(b => b.classList.remove('active'));
        e.target.classList.add('active');
        selectedClass = e.target.dataset.class;
    });
});

document.getElementById('settings-btn').addEventListener('click', () => { document.getElementById('settings-modal').classList.remove('hidden'); });

document.getElementById('close-settings-btn').addEventListener('click', () => {
    window.gameSettings.highQuality = document.getElementById('set-hq').checked;
    window.gameSettings.showNames = document.getElementById('set-names').checked;
    window.gameSettings.showFps = document.getElementById('set-fps').checked;
    
    const fpsDisplay = document.getElementById('fps-display');
    if (window.gameSettings.showFps) fpsDisplay.classList.remove('hidden');
    else fpsDisplay.classList.add('hidden');

    document.getElementById('settings-modal').classList.add('hidden');
});

let listeningAction = null;
const formatKeyName = (key) => key === ' ' ? 'SPACE' : key.toUpperCase();

document.querySelectorAll('.keybind-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
        document.querySelectorAll('.keybind-btn').forEach(b => b.classList.remove('listening'));
        listeningAction = e.target.dataset.action;
        e.target.classList.add('listening');
        e.target.innerText = "PRESS KEY";
    });
});

document.addEventListener('keydown', (e) => {
    if (listeningAction) {
        e.preventDefault(); 
        const key = e.key.toLowerCase();
        window.gameSettings.keybinds[listeningAction] = key;
        const btn = document.querySelector(`.keybind-btn[data-action="${listeningAction}"]`);
        btn.innerText = formatKeyName(key);
        btn.classList.remove('listening');
        listeningAction = null;
    }
});

document.getElementById('play-btn').addEventListener('click', () => {
    document.getElementById('main-menu').classList.add('hidden');
    document.getElementById('game-container').classList.remove('hidden');
    game.start(selectedClass);
});

document.getElementById('return-lobby-btn').addEventListener('click', () => {
    document.getElementById('game-over-screen').classList.add('hidden');
    document.getElementById('game-container').classList.add('hidden');
    document.getElementById('main-menu').classList.remove('hidden');
    document.getElementById('menu-level').innerText = window.globalAccountLevel;

    if (window.lastMatchStats) {
        window.hourlyStats.kills += window.lastMatchStats.kills;
        window.hourlyStats.time += window.lastMatchStats.time;
        window.hourlyStats.points += window.lastMatchStats.points;
        window.hourlyStats.distance += window.lastMatchStats.distance;
        window.lastMatchStats = null; 
    }
});

// --- NEW: EQUIP LOGIC ---
window.toggleEquip = (itemId) => {
    const item = window.ITEMS_DB[itemId];
    if (!item) return;
    
    // Toggle
    if (window.equippedItems[item.category] === itemId) {
        window.equippedItems[item.category] = null;
    } else {
        window.equippedItems[item.category] = itemId;
    }
    
    // Refresh all menus to update button states
    renderLocker();
    renderSeasonStore();
    renderMainStore();
};

document.body.addEventListener('click', (e) => {
    if (e.target.classList.contains('btn-equip')) {
        window.toggleEquip(e.target.dataset.id);
    }
});

// --- RENDER FUNCTIONS ---
function renderLocker() {
    const grid = document.getElementById('locker-grid');
    grid.innerHTML = '';
    
    const claimedKeys = Object.keys(window.claimedItems);
    if (claimedKeys.length === 0) {
        grid.innerHTML = '<p style="color: #aaa; margin-top: 20px;">You haven\'t claimed any items yet! Play matches to unlock gear.</p>';
        return;
    }

    claimedKeys.forEach(id => {
        const item = window.ITEMS_DB[id];
        if (!item) return;
        
        // Find color dynamically if it's a main store item
        let color = item.color;
        if (!color) {
            color = RARITY_COLORS[getRarityScore(item.type, item.req)];
        }
        
        const isEquipped = window.equippedItems[item.category] === item.id;
        
        const html = `
            <div class="store-item unlocked" style="--rarity-color: ${color};">
                <div class="item-icon">${item.icon}</div>
                <div style="font-size: 0.8rem; color: ${color}; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; margin-bottom: -5px; text-shadow: 0 0 5px ${color}40;">${item.category}</div>
                <div class="item-name">${item.name}</div>
                <button class="btn-equip ${isEquipped ? 'equipped' : ''}" data-id="${item.id}">
                    ${isEquipped ? '✓ EQUIPPED' : 'EQUIP'}
                </button>
            </div>
        `;
        grid.innerHTML += html;
    });
}

function renderSeasonStore() {
    const grid = document.getElementById('season-grid');
    grid.innerHTML = '';
    
    const progressPercent = Math.min(100, (window.globalAccountLevel / 50) * 100);
    document.getElementById('season-progress-bar').style.width = `${progressPercent}%`;

    const sItems = ['s_banner', 's_trail', 's_skin1', 's_skin2'];

    sItems.forEach(id => {
        const item = window.ITEMS_DB[id];
        const isUnlocked = window.globalAccountLevel >= item.req;
        const isClaimed = window.claimedItems[item.id];
        const isEquipped = window.equippedItems[item.category] === item.id;
        
        let buttonHtml = '';
        if (isUnlocked && !isClaimed) {
            buttonHtml = `<button class="btn-claim" data-id="${item.id}"><div class="fill"></div><span>HOLD TO CLAIM</span></button>`;
        } else if (isClaimed) {
            buttonHtml = `<button class="btn-equip ${isEquipped ? 'equipped' : ''}" data-id="${item.id}">${isEquipped ? '✓ EQUIPPED' : 'EQUIP'}</button>`;
        }

        const html = `
            <div class="store-item ${isUnlocked ? 'unlocked' : 'locked'}" style="--rarity-color: ${item.color};">
                <div class="item-icon">${item.icon}</div>
                <div style="font-size: 0.8rem; color: ${item.color}; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; margin-bottom: -5px; text-shadow: 0 0 5px ${item.color}40;">${item.category}</div>
                <div class="item-name">${item.name}</div>
                <div class="item-req" style="color: ${item.color};">${isClaimed ? '✓ CLAIMED' : isUnlocked ? 'UNLOCKED!' : `Requires Level ${item.req}`}</div>
                ${buttonHtml}
            </div>
        `;
        grid.innerHTML += html;
    });
}

function renderMainStore() {
    const grid = document.getElementById('main-store-grid');
    grid.innerHTML = '';
    
    let shopItems = [
        window.ITEMS_DB['m_skin'],
        window.ITEMS_DB['m_banner'],
        window.ITEMS_DB['m_trail'],
        window.ITEMS_DB['m_color']
    ];

    shopItems.sort((a, b) => getRarityScore(a.type, a.req) - getRarityScore(b.type, b.req));

    shopItems.forEach(item => {
        const currentValue = window.hourlyStats[item.type];
        const isUnlocked = currentValue >= item.req;
        const isClaimed = window.claimedItems[item.id];
        const isEquipped = window.equippedItems[item.category] === item.id;
        const progressPercent = Math.min(100, (currentValue / item.req) * 100);
        
        const rarityScore = getRarityScore(item.type, item.req);
        const color = RARITY_COLORS[rarityScore];
        
        let buttonHtml = '';
        if (isUnlocked && !isClaimed) {
            buttonHtml = `<button class="btn-claim" data-id="${item.id}"><div class="fill"></div><span>HOLD TO CLAIM</span></button>`;
        } else if (isClaimed) {
            buttonHtml = `<button class="btn-equip ${isEquipped ? 'equipped' : ''}" data-id="${item.id}">${isEquipped ? '✓ EQUIPPED' : 'EQUIP'}</button>`;
        } else {
            buttonHtml = `<div class="item-progress-bg"><div class="item-progress-fill" style="width: ${progressPercent}%; background: ${color}; box-shadow: 0 0 10px ${color};"></div></div>`;
        }
        
        const html = `
            <div class="store-item ${isUnlocked ? 'unlocked' : 'locked'}" style="--rarity-color: ${color};">
                <div class="item-icon">${item.icon}</div>
                <div style="font-size: 0.8rem; color: ${color}; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; margin-bottom: -5px; text-shadow: 0 0 5px ${color}40;">${item.category}</div>
                <div class="item-name">${item.name}</div>
                <div class="item-req" style="color: ${color};">${isClaimed ? '✓ CLAIMED' : isUnlocked ? 'UNLOCKED!' : `${Math.floor(currentValue)} / ${item.req} ${item.label}`}</div>
                ${buttonHtml}
            </div>
        `;
        grid.innerHTML += html;
    });
}

const startClaim = (e) => {
    const btn = e.target.closest('.btn-claim');
    if (!btn) return;
    
    const itemId = btn.dataset.id;
    const storeItem = btn.closest('.store-item');
    
    btn.classList.add('holding');
    storeItem.classList.add('shaking');

    btn.claimTimeout = setTimeout(() => {
        window.claimedItems[itemId] = true;
        btn.classList.remove('holding');
        storeItem.classList.remove('shaking');
        storeItem.classList.add('claimed-pop');
        
        setTimeout(() => {
            renderSeasonStore();
            renderMainStore();
            renderLocker();
        }, 500); 
    }, 1000); 
};

const stopClaim = (e) => {
    document.querySelectorAll('.btn-claim.holding').forEach(btn => {
        clearTimeout(btn.claimTimeout);
        btn.classList.remove('holding');
        btn.closest('.store-item').classList.remove('shaking');
    });
};

document.body.addEventListener('mousedown', startClaim);
document.body.addEventListener('touchstart', startClaim, {passive: true});
document.body.addEventListener('mouseup', stopClaim);
document.body.addEventListener('mouseleave', stopClaim);
document.body.addEventListener('touchend', stopClaim);

setInterval(() => {
    const now = new Date();
    const minutes = 59 - now.getMinutes();
    const seconds = 59 - now.getSeconds();
    document.getElementById('shop-timer').innerText = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

    if (now.getHours() !== currentShopHour) {
        currentShopHour = now.getHours();
        window.hourlyStats = { kills: 0, time: 0, points: 0, distance: 0 };
        if (document.getElementById('store').classList.contains('active')) renderMainStore();
    }
}, 1000);

renderSeasonStore();
renderMainStore();

// Developer Console
const devConsole = document.getElementById('dev-console');
const devInput = document.getElementById('dev-input');
const devLog = document.getElementById('dev-log');

function logDev(msg) {
    devLog.innerHTML += `<div>> ${msg}</div>`;
    devLog.scrollTop = devLog.scrollHeight;
}

window.addEventListener('keydown', (e) => {
    if (e.key === '`') {
        e.preventDefault();
        devConsole.classList.toggle('hidden');
        if (!devConsole.classList.contains('hidden')) devInput.focus();
    }
});

devInput.addEventListener('keydown', (e) => {
    if (e.key === '`') { e.preventDefault(); return; }
    if (e.key === 'Enter') {
        const val = devInput.value.trim();
        if (!val) return;
        
        logDev(val);
        devInput.value = '';
        
        const parts = val.split(' ');
        const cmd = parts[0].toLowerCase();
        const arg = parseInt(parts[1]);

        if (cmd === '/level' && !isNaN(arg)) {
            window.globalAccountLevel = arg;
            document.getElementById('menu-level').innerText = arg;
            renderSeasonStore();
            logDev(`[SUCCESS] Account Level set to ${arg}.`);
        }
        else if (cmd === '/kills' && !isNaN(arg)) {
            window.hourlyStats.kills = arg; renderMainStore(); logDev(`[SUCCESS] Hourly kills set to ${arg}.`);
        }
        else if (cmd === '/dist' && !isNaN(arg)) {
            window.hourlyStats.distance = arg; renderMainStore(); logDev(`[SUCCESS] Hourly distance set to ${arg}.`);
        }
        else if (cmd === '/time' && !isNaN(arg)) {
            window.hourlyStats.time = arg; renderMainStore(); logDev(`[SUCCESS] Hourly time set to ${arg}.`);
        }
        else if (cmd === '/points' && !isNaN(arg)) {
            window.hourlyStats.points = arg; renderMainStore(); logDev(`[SUCCESS] Hourly points set to ${arg}.`);
        }
        else if (cmd === '/help') {
            logDev('Commands: /level [num], /kills [num], /dist [num], /time [num], /points [num]');
        }
        else {
            logDev('<span style="color: red;">[ERROR] Unknown command.</span>');
        }
    }
});